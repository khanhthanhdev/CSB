str = input("Input a text: ")
if str == str[::-1]:
    print("This is a palindrome")
else:
    print("This is not a palindrome")