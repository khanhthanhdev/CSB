n1 = int(input("Input first number: "))
n2 = int(input("Input second number: "))
sum = n1 + n2
print(f"{n1} + {n2} = {sum}")